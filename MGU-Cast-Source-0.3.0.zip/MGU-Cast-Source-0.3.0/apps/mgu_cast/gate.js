'use strict';
// GPL-3.0-or-later. Native embedded display ownership is required.
function reason(s,now){
 if(!s.releaseApproved)return 'Video disabled until live-decoder and camera-preemption tests pass';
 if(!s.visible||!s.focus)return 'Open the video page';
 if(!s.embed||!s.frontGate||!s.front)return 'Embedded display and foreground gate required';
 return '';
}
function fit(sw,sh,w,h){if(!([sw,sh,w,h].every(Number.isFinite)&&sw>0&&sh>0&&w>0&&h>0))return null;var scale=Math.min(w/sw,h/sh);return {x:(w-sw*scale)/2,y:(h-sh*scale)/2,w:sw*scale,h:sh*scale};}
module.exports={reason:reason,fit:fit};
