'use strict';
// GPL-3.0-or-later. Embedded-only beta. No layer fallback, input grab or audio.
const net=require('net'),fs=require('fs'),mgu=require('./kit/mgu');
const {RenderClient,videoOp}=require('./mgu_render_client');
const gate=require('./gate');
const mono=()=>{const t=process.hrtime();return t[0]*1000+t[1]/1e6;};

mgu.run({async start(ctx){
 const {ui,log}=ctx;
 const s={releaseApproved:false,visible:false,focus:false,embed:false,frontGate:false,front:false};
 let socket=null,gpu=null,box=null,inbuf='',want=false,registered=false,frames=0,frameAt=0,brokerReady=false;
 const text=t=>ui.text('STATUS',t);
 const tell=x=>{if(socket&&!socket.destroyed)socket.write(JSON.stringify(x)+'\n');};
 function halt(){want=false;tell({type:'stop'});if(gpu)gpu.show(false);}
 function connect(){if(socket&&!socket.destroyed)return;socket=net.connect('/run/mgu-cast/ctl.sock');
  socket.on('error',()=>{halt();text('Receiver service unavailable');});socket.on('close',()=>{halt();socket=null;});
  socket.on('data',d=>{inbuf+=d.toString();if(inbuf.length>65536){socket.destroy();return;}let n;while((n=inbuf.indexOf('\n'))>=0){let ev;try{ev=JSON.parse(inbuf.slice(0,n));}catch(e){socket.destroy();return;}inbuf=inbuf.slice(n+1);
   if(ev.ready){brokerReady=true;s.releaseApproved=ev.videoReleaseApproved===true;}
   if(ev.pairing_pin)ui.text('VIDEO_TITLE','MGU Cast — enter '+String(ev.pairing_pin));
   if(ev.decoded_frames!==undefined&&ev.decoded_frames!==frames){frames=ev.decoded_frames;frameAt=mono();}
   if(ev.stopped||ev.error){halt();text(ev.error||'Test ended. Select Start for another session.');}
  }});
 }
 gpu=new RenderClient('mgu_cast',log,{mode:'embed'});
 gpu.on('ready',(screen,info)=>{if(!info){halt();return;}s.embed=info.modes.indexOf('embed')>=0&&info.video;s.frontGate=info.frontGate===true;box=info.embedBox;if(!s.embed||!s.frontGate){halt();text('Required embedded renderer capability unavailable');return;}gpu.mode('embed');gpu.place({x:box.x,y:box.y,w:box.w,h:box.h,scale:1,ox:0,oy:0});});
 gpu.on('state',st=>{s.front=st.front===true;if(!s.front)halt();});gpu.on('close',()=>{s.embed=false;halt();});gpu.on('error',()=>halt());gpu.connect();
 ui.onVisible((name,on)=>{if(name==='VIDEO'){s.visible=on;s.focus=on;if(!on)halt();}});ui.onFocus((name,on)=>{if(name==='VIDEO'){s.focus=on;if(!on)halt();}});
 ui.onClick('START',()=>{connect();if(!s.releaseApproved){text('Beta installed. Video validation is not complete yet.');return;}want=true;ui.open('VIDEO').then(()=>tell({type:'start'}));});
 ui.onClick('STOP',()=>{halt();ui.open('MAIN');});
 const timer=setInterval(()=>{
  const now=mono();
  const why=gate.reason(s);tell({type:'pulse',allowed:want&&!why});
  if(why){if(gpu)gpu.show(false);text(why);return;}
  if(!want||!box)return;
  if(!registered&&fs.existsSync('/dev/shm/mgu-video-mgu-cast')){gpu.video(1,'/dev/shm/mgu-video-mgu-cast');registered=true;}
  const clear=new Uint32Array([1,0x000000ff]);
  if(registered&&mono()-frameAt<1500){const v=videoOp(1,0,0,box.w,box.h,0),ops=new Uint32Array(clear.length+v.length);ops.set(clear);ops.set(v,clear.length);gpu.frameWords(ops);gpu.show(true);}else{gpu.frameWords(clear);gpu.show(false);}
 },250);
 ctx.app.on('shutdown',()=>{clearInterval(timer);halt();if(socket)socket.end();if(gpu)gpu.close();});
 connect();text('MGU Cast beta: landscape canvas; rotate iPhone before mirroring.');
}});
