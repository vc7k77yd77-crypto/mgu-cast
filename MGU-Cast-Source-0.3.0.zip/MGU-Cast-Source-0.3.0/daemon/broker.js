'use strict';
// GPL-3.0-or-later. Local root supervisor; never listens on an IP socket.
var fs=require('fs'),net=require('net'),cp=require('child_process'),path=require('path');
process.title='mgu-cast';
var base=__dirname,run='/run/mgu-cast',sock=run+'/ctl.sock',active=null,guard=null;
function uid(){try{return JSON.parse(fs.readFileSync('/var/opt/mgu-deploy/state.json','utf8')).apps.mgu_cast.uid;}catch(e){return -1;}}
function stop(){if(guard){guard.kill('SIGTERM');var c=guard;setTimeout(function(){if(guard===c)c.kill('SIGKILL');},6000).unref();}}
function send(s,x){if(!s.destroyed)s.write(JSON.stringify(x)+'\n');}
function pulseOK(x){return x&&x.type==='pulse'&&x.allowed===true;}
if(!fs.existsSync(run))fs.mkdirSync(run,493);
if(fs.existsSync(sock))fs.unlinkSync(sock);
var group=fs.readFileSync('/etc/group','utf8').split('\n').filter(function(l){return l.split(':')[0]==='tm_oap_app';})[0];
if(!group)throw Error('Missing app group');group=Number(group.split(':')[2]);
var server=net.createServer(function(s){
 var peer;try{peer=Number(cp.execFileSync(path.join(base,'peeruid'),[],{stdio:['ignore','pipe','ignore',s._handle.fd],encoding:'utf8',timeout:1000}));}catch(e){s.destroy();return;}
 if(peer!==uid()||peer<1||active){s.destroy();return;}
 active=s;var last=0,want=false,buffer='';
 function start(){if(guard||!want||Date.now()-last>1000)return;
  var a={binaryPath:path.join(base,'airplay-sink'),video:true};
  a.sha256=require('crypto').createHash('sha256').update(fs.readFileSync(a.binaryPath)).digest('hex');
  guard=cp.spawn(process.execPath,[path.join(base,'guard.js')],{env:Object.assign({},process.env,{MGU_TEST_ARGS:JSON.stringify(a)}),stdio:['ignore','pipe','pipe']});
  var out='';guard.stdout.on('data',function(d){out+=d.toString();if(out.length>65536){stop();return;}var n;while((n=out.indexOf('\n'))>=0){var l=out.slice(0,n);out=out.slice(n+1);try{send(s,JSON.parse(l));}catch(e){}}});
  guard.stderr.on('data',function(){send(s,{error:'Receiver supervisor reported an error'});});
  guard.on('close',function(){guard=null;want=false;send(s,{stopped:true});});
 }
 s.on('data',function(d){buffer+=d.toString();if(buffer.length>4096){s.destroy();return;}var n;
  while((n=buffer.indexOf('\n'))>=0){var l=buffer.slice(0,n);buffer=buffer.slice(n+1);var x;try{x=JSON.parse(l);}catch(e){s.destroy();return;}
   if(pulseOK(x)){last=Date.now();start();}else if(x.type==='start'){want=true;start();}else if(x.type==='stop'||x.type==='pulse'){want=false;last=0;stop();}
  }
 });
 var timer=setInterval(function(){if(guard&&Date.now()-last>1000){want=false;stop();}},200);
 s.on('error',function(){});s.on('close',function(){clearInterval(timer);want=false;last=0;stop();active=null;});
 send(s,{ready:true,videoReleaseApproved:false});
});
server.listen(sock,function(){fs.chownSync(sock,0,group);fs.chmodSync(sock,432);});
process.on('SIGTERM',function(){stop();server.close();setTimeout(function(){process.exit(0);},6500);});
module.exports={pulseOK:pulseOK};
