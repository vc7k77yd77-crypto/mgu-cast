'use strict';
// Root supervisor only. Worker drops privilege before it opens sockets.
var fs=require('fs'),cp=require('child_process'),crypto=require('crypto'),os=require('os');
var args=JSON.parse(process.env.MGU_TEST_ARGS);
delete process.env.MGU_TEST_ARGS;
var ip=(os.networkInterfaces().wlan0||[]).filter(function(a){return a.family==='IPv4'&&/^172\.20\.10\.(?:[2-9]|1[0-4])$/.test(a.address);});
if(ip.length!==1)throw Error('Expected single iPhone hotspot IPv4');ip=ip[0].address;
var token='mgu-cast-'+crypto.randomBytes(8).toString('hex');
var chains=[['inet','mgu_uplink','input'],['inet','mgu_uplink','output'],['ip','filter','input']];
function nft(a,stdin){
 var d,p;if(stdin){d=fs.mkdtempSync('/tmp/mgu-nft-check-');fs.chmodSync(d,448);p=d+'/rules.nft';fs.writeFileSync(p,stdin,{flag:'wx',mode:384});a=a.map(function(v){return v==='-'?p:v;});}
 try{return cp.execFileSync('/usr/sbin/nft',a,{encoding:'utf8',timeout:5000,maxBuffer:262144});}
 finally{if(p){fs.unlinkSync(p);fs.rmdirSync(d);}}
}
var rules=[];
['inet mgu_uplink input','ip filter input'].forEach(function(chain){
 rules.push('insert rule '+chain+' iifname "wlan0" ip saddr 172.20.10.1 ip daddr { '+ip+', 224.0.0.251 } udp sport 5353 udp dport 5353 counter accept comment "'+token+'"');
 rules.push('insert rule '+chain+' iifname "wlan0" ip saddr 172.20.10.1 ip daddr '+ip+' tcp dport { 42070, 42071 } counter accept comment "'+token+'"');
 rules.push('insert rule '+chain+' iifname "wlan0" ip saddr 172.20.10.1 ip daddr '+ip+' udp dport { 42073, 42074, 42075 } counter accept comment "'+token+'"');
});
rules.push('insert rule inet mgu_uplink output oifname "wlan0" meta skuid 65534 ip saddr '+ip+' ip daddr { 172.20.10.1, 224.0.0.251 } udp sport 5353 udp dport 5353 counter accept comment "'+token+'"');
rules.push('insert rule inet mgu_uplink output oifname "wlan0" meta skuid 65534 ip saddr '+ip+' ip daddr 172.20.10.1 udp sport { 42073, 42074, 42075 } counter accept comment "'+token+'"');
var transaction=rules.join('\n')+'\n';
nft(['-c','-f','-'],transaction);
if(args.dryrun){console.log(JSON.stringify({firewall_dryrun:true,rules:rules.length,scope:'wlan0, iPhone 172.20.10.1, fixed test ports'}));process.exit(0);}
var b=args.binaryPath?fs.readFileSync(args.binaryPath):Buffer.from(args.binary,'base64');if(crypto.createHash('sha256').update(b).digest('hex')!==args.sha256)throw Error('checksum');
if(args.video&&fs.existsSync('/dev/shm/mgu-video-mgu-cast'))throw Error('An existing video frame file prevents starting');
var dir=fs.mkdtempSync('/tmp/mgu-airplay-guarded-'),bin=dir+'/sink';fs.chmodSync(dir,493);fs.writeFileSync(bin,b,{mode:493,flag:'wx'});
// Cleanup is identifier-based, never a full ruleset restore. Run independently
// of the worker and SSH supervisor, and only delete this session's own rules.
// Use a plain function serialization to avoid shell quoting and code-string
// escaping in the rule parser.
function cleanSession(token,chains){
 var cp=require('child_process'),ok=true;
 chains.forEach(function(c){try{
  var s=cp.execFileSync('/usr/sbin/nft',['-a','list','chain'].concat(c),{encoding:'utf8',timeout:5000,maxBuffer:262144});
  s.split('\n').forEach(function(l){if(l.indexOf('comment "'+token+'"')>=0){var m=/\bhandle\s+(\d+)/.exec(l);if(!m)throw Error('Missing rule handle');cp.execFileSync('/usr/sbin/nft',['delete','rule'].concat(c).concat(['handle',m[1]]),{timeout:5000});}});
 }catch(e){ok=false;}});return ok;
}
var call='('+cleanSession.toString()+')('+JSON.stringify(token)+','+JSON.stringify(chains)+')';
var guard=cp.spawn(process.execPath,['-e','setTimeout(function(){'+call+';},150000);'],{detached:true,stdio:'ignore'});guard.unref();
var child,timer,finished=false;
process.on('SIGTERM',function(){if(child){child.kill('SIGTERM');setTimeout(function(){child.kill('SIGKILL');},4000).unref();}else finish(1);});
function finish(code){
 if(finished)return;finished=true;
 if(timer)clearTimeout(timer);
 var ok=cleanSession(token,chains);
 var remaining=0;
 chains.forEach(function(c){try{remaining+=nft(['-a','list','chain'].concat(c)).split('\n').filter(function(l){return l.indexOf('comment "'+token+'"')>=0;}).length;}catch(e){remaining=-1000;}});
 console.log(JSON.stringify({firewall_cleanup:ok&&remaining===0,remaining_test_rules:remaining}));
 if(args.video){var f='/dev/shm/mgu-video-mgu-cast';try{var st=fs.lstatSync(f);if(st.isFile()&&st.uid===65534)fs.unlinkSync(f);}catch(e){}}
 try{fs.unlinkSync(bin);fs.rmdirSync(dir);console.log('{"temporary_files_removed":true}');}catch(e){console.error('Temporary file cleanup failed');}
 process.exitCode=code||0;
}
try{
 nft(['-f','-'],transaction);
 console.log(JSON.stringify({temporary_firewall_rules:rules.length,guard_seconds:150}));
 child=cp.spawn(bin,['--run',ip].concat(args.video?['--video']:[]),{cwd:dir,env:Object.assign({},process.env,{LD_BIND_NOW:'1'}),stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',function(d){process.stdout.write(d);});child.stderr.on('data',function(d){process.stderr.write(d);});
 timer=setTimeout(function(){child.kill('SIGTERM');setTimeout(function(){child.kill('SIGKILL');},5000).unref();},125000);
 child.on('close',function(code){finish(code);});child.on('error',function(){finish(1);});
}catch(e){console.error(String(e));finish(1);}
