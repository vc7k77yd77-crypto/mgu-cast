// SPDX-License-Identifier: GPL-3.0-or-later
#define _GNU_SOURCE
#include <sys/socket.h>
#include <stdio.h>
int main(void){struct ucred c; socklen_t n=sizeof(c);if(getsockopt(3,SOL_SOCKET,SO_PEERCRED,&c,&n)||n!=sizeof(c))return 1;printf("%u\n",c.uid);return 0;}
