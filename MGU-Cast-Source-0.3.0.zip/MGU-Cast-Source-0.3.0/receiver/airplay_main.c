// SPDX-License-Identifier: GPL-3.0-or-later
// Experimental headless AirPlay sink. Media is counted and discarded.
#define _GNU_SOURCE
#include "raop.h"
#include "netutils.h"
#include <openssl/crypto.h>
#include <plist/plist.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdatomic.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/resource.h>
#include <grp.h>
#include <pthread.h>
static volatile sig_atomic_t stop;
static atomic_ullong video_packets,video_bytes,audio_packets;
static pthread_mutex_t registry_lock=PTHREAD_MUTEX_INITIALIZER;
static char trusted[128];
static int output_video=0;
static atomic_int reset_decoder;
#include "live_decode.h"
static void stop_it(int s){(void)s;stop=1;}
static void nothing(void*c){(void)c;}
static void reset(void*c,int r){(void)c;(void)r;}
static void vreset(void*c,reset_type_t r){(void)c;(void)r;atomic_store(&reset_decoder,1);}
static void video(void*c,raop_ntp_t*n,video_decode_struct*d){(void)c;(void)n;if(d&&d->data_len>0){atomic_fetch_add(&video_packets,1);atomic_fetch_add(&video_bytes,(unsigned)d->data_len);if(output_video){if(atomic_exchange(&reset_decoder,0))live_stop_decoder();if(!live_feed(d->data,d->data_len)){atomic_fetch_add(&decode_errors,1);stop=1;}}}}
static void audio(void*c,raop_ntp_t*n,audio_decode_struct*d){(void)c;(void)n;(void)d;atomic_fetch_add(&audio_packets,1);}
static double volume(void*c){(void)c;return -30.0;}
static void setvolume(void*c,float v){(void)c;(void)v;}
static int codec(void*c,video_codec_t co,unsigned short sw,unsigned short sh,unsigned short x,unsigned short y,unsigned short w,unsigned short h){(void)c;(void)x;(void)y;if(output_video&&live.ready&&(w!=live.w||h!=live.h))atomic_store(&reset_decoder,1);printf("{\"codec_event\":%d,\"source_w\":%u,\"source_h\":%u,\"w\":%u,\"h\":%u}\n",co,sw,sh,w,h);fflush(stdout);return co==VIDEO_CODEC_H264?0:-1;}
static void pin(void*c,char*p){(void)c;printf("{\"pairing_pin\":\"%.4s\"}\n",p);fflush(stdout);}
static bool registered(void*c,const char*k){(void)c;pthread_mutex_lock(&registry_lock);bool match=k&&trusted[0]&&!strcmp(k,trusted);pthread_mutex_unlock(&registry_lock);return match;}
static void reg(void*c,const char*d,const char*k,const char*n){(void)c;(void)d;(void)n;pthread_mutex_lock(&registry_lock);if(k&&strlen(k)<sizeof(trusted))strcpy(trusted,k);pthread_mutex_unlock(&registry_lock);puts("{\"pairing_completed\":true}");fflush(stdout);}
static void admit(void*c,char*d,char*m,char*n,bool*a){(void)c;(void)d;(void)m;(void)n;*a=true;puts("{\"client_request\":true}");fflush(stdout);}
static void logmsg(void*c,int l,const char*m){(void)c;(void)m;/* no upstream logs containing identifiers or keys */if(l<=3){printf("{\"upstream_log_level\":%d}\n",l);fflush(stdout);}}
int main(int argc,char**argv){
 if((argc==3||argc==4)&&!strcmp(argv[1],"--decode-sample")){
  FILE*f=fopen(argv[2],"rb");unsigned char b[262144];size_t n=f?fread(b,1,sizeof(b),f):0;if(f)fclose(f);
  if(!n||n==sizeof(b)||!live_prepare()){live_close();return 1;}
  int ok=live_feed(b,(int)n);printf("{\"sample_decode\":%s,\"frames\":%llu,\"width\":%u,\"height\":%u}\n",ok?"true":"false",atomic_load(&decoded_frames),live.w,live.h);
  if(argc==4&&ok&&live.ready){unsigned*h=live.map;FILE*out=fopen(argv[3],"wbx");if(out){fwrite((unsigned char*)live.map+64+h[5]*live.bytes,1,live.bytes,out);fclose(out);}else ok=0;}
  live_close();return ok&&atomic_load(&decoded_frames)>0?0:1;
 }
 if(argc==2&&!strcmp(argv[1],"--check")){
  plist_t p=plist_new_dict();plist_dict_set_item(p,"test",plist_new_uint(123));char*b=NULL;uint32_t n=0;plist_to_bin(p,&b,&n);plist_t q=NULL;plist_from_bin(b,n,&q);uint64_t v=0;if(q)plist_get_uint_val(plist_dict_get_item(q,"test"),&v);free(b);plist_free(p);plist_free(q);
  printf("{\"library_check\":%s,\"openssl_version\":\"%s\"}\n",v==123?"true":"false",OpenSSL_version(0));return v==123?0:1;
 }
 if((argc!=3&&argc!=4)||strcmp(argv[1],"--run")){fputs("Usage: airplay-sink --check | --run <local-ipv4>\n",stderr);return 64;}
 struct in_addr local;if(inet_pton(AF_INET,argv[2],&local)!=1)return 64;
 setenv("MGU_AIRPLAY_BIND",argv[2],1);
 output_video=argc==4&&!strcmp(argv[3],"--video");
 if(output_video&&!live_prepare()){live_close();return 71;}
 // Worker has no root, video/audio group or durable identity.
 if(getuid()==0){if(setgroups(0,NULL)||setgid(65534)||setuid(65534))return 70;}
 if(getuid()==0)return 70;
 struct rlimit lim={256*1024*1024,256*1024*1024};if(setrlimit(RLIMIT_AS,&lim))return 70;
 lim.rlim_cur=lim.rlim_max=0;setrlimit(RLIMIT_CORE,&lim);
 signal(SIGINT,stop_it);signal(SIGTERM,stop_it);signal(SIGALRM,stop_it);alarm(120);netutils_init();
 raop_callbacks_t cb={0};cb.audio_process=audio;cb.video_process=video;cb.conn_init=nothing;cb.conn_destroy=nothing;cb.conn_feedback=nothing;cb.conn_reset=reset;cb.video_reset=vreset;cb.video_pause=nothing;cb.video_resume=nothing;cb.video_flush=nothing;cb.audio_flush=nothing;cb.audio_set_client_volume=volume;cb.audio_set_volume=setvolume;cb.video_set_codec_and_size=codec;cb.display_pin=pin;cb.check_register=registered;cb.register_client=reg;cb.report_client_request=admit;
 raop_t*r=raop_init(&cb);if(!r)return 1;raop_set_log_callback(r,logmsg,NULL);raop_set_log_level(r,3);
 const char *id="02:4D:47:55:00:01";unsigned char mac[6]={2,0x4d,0x47,0x55,0,1};
 if(raop_init2(r,0,id,""))return 2;
 raop_set_plist(r,"width",1280);raop_set_plist(r,"height",720);raop_set_plist(r,"maxFPS",30);raop_set_plist(r,"pin",1);
 int error=0;dnssd_t*d=dnssd_init("MGU Cast Test",13,(char*)mac,6,1,&error);if(!d)return 3;
 dnssd_set_airplay_features(d,42,0);dnssd_set_airplay_features(d,0,0);dnssd_set_airplay_features(d,4,0);
 raop_set_dnssd(r,d);unsigned short tcp[2]={42071,42070},udp[3]={42073,42074,42075};raop_set_tcp_ports(r,tcp);raop_set_udp_ports(r,udp);unsigned short port=42070;
 if(raop_start_httpd(r,&port)<0)return 4;raop_set_port(r,port);
 int a=dnssd_register_airplay(d,port),b=dnssd_register_raop(d,port);
 printf("{\"receiver_started\":%s,\"airplay_registration\":%d,\"raop_registration\":%d,\"port\":%u,\"uid\":%u,\"duration_seconds\":120,\"display\":false,\"audio_output\":false}\n",(!a&&!b)?"true":"false",a,b,port,(unsigned)getuid());fflush(stdout);
 if(a||b)stop=1;
 unsigned ticks=0;
 while(!stop){fd_set f;FD_ZERO(&f);int max=-1;for(int i=0;i<2;i++){int fd=dnssd_get_service_fd(d,i);if(fd>=0&&fd<FD_SETSIZE){FD_SET(fd,&f);if(fd>max)max=fd;}}
  struct timeval tv={1,0};int result=select(max+1,&f,NULL,NULL,&tv);
  if(result>0)for(int i=0;i<2;i++){int fd=dnssd_get_service_fd(d,i);if(fd>=0&&fd<FD_SETSIZE&&FD_ISSET(fd,&f))if(dnssd_process_service(d,i))stop=1;}
  if(output_video){printf("{\"decoded_frames\":%llu,\"decode_errors\":%llu}\n",atomic_load(&decoded_frames),atomic_load(&decode_errors));fflush(stdout);}
  if(++ticks%5==0){printf("{\"video_packets\":%llu,\"video_bytes\":%llu,\"audio_packets\":%llu}\n",atomic_load(&video_packets),atomic_load(&video_bytes),atomic_load(&audio_packets));fflush(stdout);}
 }
 dnssd_unregister_airplay(d);dnssd_unregister_raop(d);raop_destroy(r);if(output_video)live_close();dnssd_destroy(d);netutils_cleanup();puts("{\"receiver_stopped\":true}");return a||b?5:0;
}

