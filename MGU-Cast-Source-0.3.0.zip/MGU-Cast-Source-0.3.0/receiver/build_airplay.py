import pathlib,shutil,re,subprocess,os,concurrent.futures
root=pathlib.Path.cwd();out=root/'work/airplay';out.mkdir(exist_ok=True)
src=out/'UxPlay'
if not src.exists():shutil.copytree(root/'work/UxPlay',src,ignore=shutil.ignore_patterns('.git'))
def patch(p,old,new):
 s=p.read_text();assert old in s,p;p.write_text(s.replace(old,new))
net=src/'lib/netutils.c'
if 'if(use_ipv6)' not in net.read_text():
 patch(net,'int family = use_ipv6 ? AF_INET6 : AF_INET;', 'if(use_ipv6) { errno=EAFNOSUPPORT; return -1; }\n    int family = use_ipv6 ? AF_INET6 : AF_INET;')
if 'MGU_AIRPLAY_BIND' not in net.read_text():
 patch(net,'sinptr->sin_addr.s_addr = INADDR_ANY;', 'if (!getenv("MGU_AIRPLAY_BIND") || inet_pton(AF_INET,getenv("MGU_AIRPLAY_BIND"),&sinptr->sin_addr)!=1) goto cleanup;')
 patch(net,'int family = use_ipv6 ? AF_INET6 : AF_INET;', 'if(use_ipv6) { errno=EAFNOSUPPORT; return -1; }\n    int family = use_ipv6 ? AF_INET6 : AF_INET;')
dns=src/'lib/dns_sd/dns_sd.c'
if '#include <dns_sd.h>' in dns.read_text():patch(dns,'#include <dns_sd.h>','/* Linux dlopen backend declares the required DNS-SD ABI below. */')
if 'if_nametoindex' not in dns.read_text():
 patch(dns,'#include <assert.h>','#include <assert.h>\n#include <net/if.h>')
 patch(dns,'uint32_t interface_index = 0;','uint32_t interface_index = if_nametoindex("wlan0"); if(!interface_index) return -1;')
http=src/'lib/httpd.c'
if 'MGU peer restriction' not in http.read_text():
 patch(http,'local_saddrlen = sizeof(local_saddr);','/* MGU peer restriction: this diagnostic accepts only the iPhone hotspot host. */\n    if (remote_saddr.ss_family != AF_INET || ((struct sockaddr_in *)&remote_saddr)->sin_addr.s_addr != inet_addr("172.20.10.1")) { CLOSESOCKET(fd); return 0; }\n    local_saddrlen = sizeof(local_saddr);')
mdns=src/'lib/mdnsd/mdnsd.c'
if 'MGU_AIRPLAY_BIND' not in mdns.read_text():
 patch(mdns,'mdnsd->ipv4_addr = mdns_get_default_ipv4();','mdnsd->ipv4_addr = inet_addr(getenv("MGU_AIRPLAY_BIND"));')
 patch(mdns,'mdnsd->sock_fd6 = mdns_open_socket6(mdnsd->ipv6_scope_id);','mdnsd->sock_fd6 = -1; /* IPv4 hotspot only */')
 patch(mdns,'mreq.imr_interface.s_addr = htonl(INADDR_ANY);','mreq.imr_interface.s_addr = iface_addr; /* no interface fallback */')
 s=mdns.read_text();mdns.write_text(s.replace('if (received > 0) {','if (received > 0 && from.sin_addr.s_addr == inet_addr("172.20.10.1")) {',1))
 patch(mdns,'setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, (const char *) &loop, sizeof(loop));','setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, (const char *) &loop, sizeof(loop));\n#ifdef IP_MULTICAST_ALL\n    int zero=0; setsockopt(fd, IPPROTO_IP, IP_MULTICAST_ALL, &zero, sizeof(zero));\n#endif')
mdns_backend=src/'lib/mdnsd/dnssd_mdnsd.c'
if 'dnssd_get_service_fd' not in mdns_backend.read_text():
 mdns_backend.write_text(mdns_backend.read_text()+'\n/* Internal mDNS services its own sockets in its worker thread. */\nint dnssd_get_service_fd(dnssd_t *d,int s){(void)d;(void)s;return -1;}\nint dnssd_process_service(dnssd_t *d,int s){(void)d;(void)s;return 0;}\n')
if 'mgu-cast-test' not in mdns_backend.read_text():
 patch(mdns_backend,'if (gethostname(host, sizeof(host)) || !host[0]) {','strcpy(host,"mgu-cast-test");\n    if (!host[0]) {')
# Build-only crypto placeholder. NEVER deploy it; real symbols resolve from target libcrypto.
texts='\n'.join(p.read_text(errors='ignore') for p in (src/'lib').glob('*.c'))+'\n'+(root/'work/airplay_main.c').read_text()
symbols=set(re.findall(r'\b((?:BIO|BN|EVP|SHA\d*|AES|RAND|PEM|RSA|ERR|OPENSSL|CRYPTO|HMAC|X509|OpenSSL)_[A-Za-z0-9_]+)\s*\(',texts))
symbols.update(['BN_div','BIO_ctrl','SHA1','SHA224','SHA256','SHA384','SHA512','CRYPTO_free','CRYPTO_malloc','EVP_MD_CTX_new','EVP_MD_CTX_free','OPENSSL_init_crypto','BN_num_bits','BN_is_negative','EVP_PKEY_get0_RSA','RSA_get0_key','EVP_CIPHER_CTX_ctrl','EVP_PKEY_CTX_ctrl','EVP_CIPHER_CTX_set_padding'])
(out/'crypto-stub.c').write_text('\n'.join('void '+s+'(void){}' for s in sorted(symbols)))
(root/'work/compiler-tmp').mkdir(exist_ok=True)
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(root/'work/zig-cache-linux');env['ZIG_LOCAL_CACHE_DIR']=str(root/'work/zig-local-cache-linux');env['TEMP']=env['TMP']=str(root/'work/compiler-tmp')
zig=os.environ.get('MGU_ZIG') or str(root/'work/toolchain/zig-windows-x86_64-0.13.0/zig.exe')
base=[zig,'cc','-target','x86_64-linux-gnu.2.27','-O2','-std=gnu11','-D_GNU_SOURCE','-DPLIST_210','-DPLIST_230','-DEXTERNAL_DNS_SD','-DHAVE_LIBDL','-DSTANDALONE','-DTARGET_POSIX','-D_LINUX','-DPLIST_STATIC','-DHAVE_MEMMEM','-DHAVE_STRNDUP','-DHAVE_STPCPY','-DPACKAGE_VERSION="2.6.0"']
def run(args):
 p=subprocess.run(args,env=env,capture_output=True)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')[-5000:])
run([zig,'cc','-target','x86_64-linux-gnu.2.27','-shared','-Wl,-soname,libcrypto.so.1.1',str(out/'crypto-stub.c'),'-o',str(out/'libcrypto-stub.so')])
plist=root/'work/libplist'
includes=[src/'lib',src/'lib/playfair',src/'lib/llhttp',plist/'include',plist/'src',plist/'libcnary/include',root/'work/openssl/include']
flags=[str(a) for p in includes for a in ['-I',p]]
sources=list((src/'lib').glob('*.c'))+list((src/'lib/playfair').glob('*.c'))+list((src/'lib/llhttp').glob('*.c'))+list((src/'lib/mdnsd').glob('*.c'))+list((plist/'src').glob('*.c'))+[plist/'libcnary/node.c',plist/'libcnary/node_list.c']+[root/'work/airplay_main.c']
def compile_one(p):
 obj=out/(p.parent.name+'-'+p.stem+'.o')
 if not obj.exists() or obj.stat().st_mtime<p.stat().st_mtime:
  run(base+flags+['-c',str(p),'-o',str(obj)])
 return str(obj)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:objects=list(pool.map(compile_one,sources))
run(base+objects+[str(out/'libcrypto-stub.so'),'-ldl','-lpthread','-lm','-Wl,--dynamic-linker=/lib/ld-linux-x86-64.so.2','-o',str(out/'airplay-sink')])
print('Built headless receiver',out/'airplay-sink',flush=True)


