// SPDX-License-Identifier: GPL-3.0-or-later
// Bounded H.264 -> Intel MSDK -> MGVF adapter. No display/audio operations.
#include "../native/mfx/mfxvideo.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#define LIVE_PATH "/dev/shm/mgu-video-mgu-cast"
typedef struct {
 int fd,framefd,ready;void *map,*va,*lv,*ld,*lm;mfxSession s;
 mfxFrameSurface1 surfaces[32];unsigned char *mem[32];unsigned n;
 unsigned w,h,sw,sh,pitch;size_t bytes;unsigned seq;
 unsigned char headers[1048576];size_t headerlen;
 void*(*display)(int);int(*vainit)(void*,int*,int*);int(*vaterm)(void*);
 mfxStatus(*init)(mfxIMPL,mfxVersion*,mfxSession*);mfxStatus(*close)(mfxSession);
 mfxStatus(*set)(mfxSession,mfxHandleType,mfxHDL);
 mfxStatus(*header)(mfxSession,mfxBitstream*,mfxVideoParam*);
 mfxStatus(*query)(mfxSession,mfxVideoParam*,mfxFrameAllocRequest*);
 mfxStatus(*decinit)(mfxSession,mfxVideoParam*);mfxStatus(*decclose)(mfxSession);
 mfxStatus(*decode)(mfxSession,mfxBitstream*,mfxFrameSurface1*,mfxFrameSurface1**,mfxSyncPoint*);
 mfxStatus(*sync)(mfxSession,mfxSyncPoint,mfxU32);
} Live;
static Live live={.fd=-1,.framefd=-1};
static atomic_ullong decoded_frames,decode_errors;
static void live_stop_decoder(void){
 if(live.ready&&live.decclose)live.decclose(live.s);live.ready=0;
 if(live.s&&live.close)live.close(live.s);live.s=NULL;
 for(unsigned i=0;i<32;i++){free(live.mem[i]);live.mem[i]=NULL;}
 live.n=0;live.headerlen=0;
}
static int live_prepare(void){
 live.fd=open("/dev/dri/renderD128",O_RDWR|O_CLOEXEC);if(live.fd<0)return 0;
 live.framefd=open(LIVE_PATH,O_RDWR|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);if(live.framefd<0)return 0;
 if(fchown(live.framefd,65534,65534))return 0;
 // 3 slots, maximum 2048x2048 bounded by renderer's 12 MiB video budget.
 size_t len=64+3*(size_t)2048*2048*3/2;
 if(ftruncate(live.framefd,(off_t)len))return 0;
 live.map=mmap(NULL,len,PROT_READ|PROT_WRITE,MAP_SHARED,live.framefd,0);
 if(live.map==MAP_FAILED){live.map=NULL;return 0;}
 memset(live.map,0,64);return 1;
}
static int live_load(void){
 live.lv=dlopen("/usr/lib/libva.so.1",RTLD_NOW|RTLD_LOCAL);live.ld=dlopen("/usr/lib/libva-drm.so.1",RTLD_NOW|RTLD_LOCAL);live.lm=dlopen("/usr/lib/libmfxhw64.so",RTLD_NOW|RTLD_LOCAL);
 if(!live.lv||!live.ld||!live.lm)return 0;
#define LS(f,l,s) do{*(void**)(&live.f)=dlsym(l,s);if(!live.f)return 0;}while(0)
 LS(display,live.ld,"vaGetDisplayDRM");LS(vainit,live.lv,"vaInitialize");LS(vaterm,live.lv,"vaTerminate");
 LS(init,live.lm,"MFXInit");LS(close,live.lm,"MFXClose");LS(set,live.lm,"MFXVideoCORE_SetHandle");
 LS(header,live.lm,"MFXVideoDECODE_DecodeHeader");LS(query,live.lm,"MFXVideoDECODE_QueryIOSurf");LS(decinit,live.lm,"MFXVideoDECODE_Init");LS(decclose,live.lm,"MFXVideoDECODE_Close");LS(decode,live.lm,"MFXVideoDECODE_DecodeFrameAsync");LS(sync,live.lm,"MFXVideoCORE_SyncOperation");
#undef LS
 live.va=live.display(live.fd);int a=0,b=0;return live.va&&live.vainit(live.va,&a,&b)==0;
}
static int live_begin(unsigned char *data,unsigned len){
 if(!live.va&&!live_load())return -1;
 if(!live.s){mfxVersion v={0};v.Major=1;v.Minor=24;if(live.init(MFX_IMPL_HARDWARE|MFX_IMPL_VIA_VAAPI,&v,&live.s)!=0||!live.s||live.set(live.s,MFX_HANDLE_VA_DISPLAY,live.va)!=0)return -1;}
 mfxBitstream bs={0};bs.Data=data;bs.DataLength=bs.MaxLength=len;
 mfxVideoParam p={0};p.mfx.CodecId=MFX_CODEC_AVC;
 int r=live.header(live.s,&bs,&p);if(r==MFX_ERR_MORE_DATA)return 0;if(r!=0)return -1;
 mfxFrameInfo *f=&p.mfx.FrameInfo;
 if(f->FourCC!=MFX_FOURCC_NV12||!f->CropW||!f->CropH||f->Width>2048||f->Height>2048||f->Width<16||f->Height<16||f->Width%2||f->Height%2||f->CropW%2||f->CropH%2||f->CropX%2||f->CropY%2||f->CropX+f->CropW>f->Width||f->CropY+f->CropH>f->Height)return -1;
 p.AsyncDepth=1;p.IOPattern=MFX_IOPATTERN_OUT_SYSTEM_MEMORY;
 mfxFrameAllocRequest req={0};if(live.query(live.s,&p,&req)!=0||req.NumFrameSuggested<1||req.NumFrameSuggested>16)return -1;
 if((size_t)f->Width*f->Height*3/2*req.NumFrameSuggested>64*1024*1024)return -1;
 live.n=req.NumFrameSuggested;live.w=f->CropW;live.h=f->CropH;live.sw=f->Width;live.sh=f->Height;live.pitch=f->Width;live.bytes=(size_t)live.w*live.h*3/2;
 for(unsigned i=0;i<live.n;i++){memset(&live.surfaces[i],0,sizeof(live.surfaces[i]));live.mem[i]=calloc(1,(size_t)f->Width*f->Height*3/2);if(!live.mem[i])return -1;live.surfaces[i].Info=*f;live.surfaces[i].Data.Y=live.mem[i];live.surfaces[i].Data.UV=live.mem[i]+(size_t)f->Width*f->Height;live.surfaces[i].Data.Pitch=f->Width;}
 if(live.decinit(live.s,&p)!=0)return -1;live.ready=1;
 unsigned *h=live.map;__atomic_store_n(h,0,__ATOMIC_RELEASE);
 memset(h,0,64);h[1]=1;h[2]=live.w;h[3]=live.h;h[6]=3;h[7]=1;
 __atomic_store_n(h,0x4656474d,__ATOMIC_RELEASE);
 printf("{\"decoder_ready\":true,\"width\":%u,\"height\":%u}\n",live.w,live.h);fflush(stdout);return 1;
}
static int live_publish(mfxFrameSurface1 *s){
 unsigned x=s->Info.CropX,y=s->Info.CropY,w=s->Info.CropW,h=s->Info.CropH,p=s->Data.Pitch;
 if(w!=live.w||h!=live.h||x%2||y%2||x+w>live.sw||y+h>live.sh||p<live.sw||!s->Data.Y||!s->Data.UV||s->Data.Corrupted)return 0;
 unsigned *head=live.map,next=(head[5]+1)%3;unsigned char*dst=(unsigned char*)live.map+64+next*live.bytes;
 for(unsigned r=0;r<h;r++)memcpy(dst+r*w,s->Data.Y+(y+r)*p+x,w);
 unsigned char*u=dst+w*h,*v=u+w*h/4;
 for(unsigned r=0;r<h/2;r++)for(unsigned c=0;c<w/2;c++){const unsigned char*uv=s->Data.UV+(y/2+r)*p+x+2*c;u[r*w/2+c]=uv[0];v[r*w/2+c]=uv[1];}
 __atomic_store_n(head+5,next,__ATOMIC_RELEASE);__atomic_store_n(head+4,++live.seq,__ATOMIC_RELEASE);atomic_fetch_add(&decoded_frames,1);return 1;
}
static int live_feed(unsigned char*data,int len){
 if(!live.map||len<=0||len>2*1024*1024)return 0;
 unsigned char*input=data;unsigned size=(unsigned)len;
 if(!live.ready){if(live.headerlen+(size_t)len>sizeof(live.headers))return 0;memcpy(live.headers+live.headerlen,data,(size_t)len);live.headerlen+=(size_t)len;int r=live_begin(live.headers,(unsigned)live.headerlen);if(r<0)return 0;if(!r)return 1;input=live.headers;size=(unsigned)live.headerlen;}
 mfxBitstream bs={0};bs.Data=input;bs.DataLength=bs.MaxLength=size;
 int busy=0;
 for(unsigned step=0;step<64;step++){
  mfxFrameSurface1*work=NULL,*out=NULL;mfxSyncPoint sync=NULL;
  for(unsigned i=0;i<live.n;i++)if(!live.surfaces[i].Data.Locked){work=&live.surfaces[i];break;}if(!work)return 0;
  int r=live.decode(live.s,&bs,work,&out,&sync);
  if(r==MFX_WRN_DEVICE_BUSY){if(++busy>100)return 0;usleep(1000);continue;}
  if(r==MFX_ERR_MORE_DATA){live.headerlen=0;return 1;}
  if(r==MFX_ERR_MORE_SURFACE)continue;
  if(r!=0)return 0;
  if(sync&&out){if(live.sync(live.s,sync,1000)!=0||!live_publish(out))return 0;}
  if(!bs.DataLength){live.headerlen=0;return 1;}
 }
 return 0;
}
static void live_close(void){live_stop_decoder();if(live.va&&live.vaterm)live.vaterm(live.va);live.va=NULL;if(live.map)munmap(live.map,64+3*(size_t)2048*2048*3/2);live.map=NULL;if(live.framefd>=0){close(live.framefd);unlink(LIVE_PATH);}if(live.fd>=0)close(live.fd);}
