'use strict';
const assert=require('assert'),fs=require('fs'),g=require('../apps/mgu_cast/gate');
const s={releaseApproved:true,visible:true,focus:true,embed:true,frontGate:true,front:true};
assert.strictEqual(g.reason(s),'');
Object.keys(s).forEach(k=>{assert(g.reason(Object.assign({},s,{[k]:false})));const a=Object.assign({},s);delete a[k];assert(g.reason(a));});
for(const dims of [[1280,720,1796,632],[332,720,1796,632]]){const r=g.fit(...dims);assert(Math.abs(r.w/r.h-dims[0]/dims[1])<1e-9);assert(r.w<=dims[2]&&r.h<=dims[3]);}
for(const n of [0,-1,NaN,Infinity])assert.strictEqual(g.fit(n,720,100,100),null);
assert.deepStrictEqual(require('../apps/mgu_cast/app.json').signals,{});
assert(!fs.readFileSync(require.resolve('../apps/mgu_cast/main'),'utf8').includes('signals.watch'));
console.log('PASS: display ownership, release gate, aspect fit, invalid dimensions, no vehicle subscriptions.');
