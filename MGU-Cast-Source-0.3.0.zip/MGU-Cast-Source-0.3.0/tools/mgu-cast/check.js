'use strict';
// No device/network checks during installation. No service is started here.
const fs=require('fs'),cp=require('child_process'),path=require('path');
['broker.js','guard.js'].forEach(f=>cp.execFileSync('/usr/bin/node',['--check',path.join(__dirname,f)]));
cp.execFileSync(path.join(__dirname,'airplay-sink'),['--check'],{timeout:5000});
console.log('MGU Cast dependencies checked; video remains disabled pending validation.');
